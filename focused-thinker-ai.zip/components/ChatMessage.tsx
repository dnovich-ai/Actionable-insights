
import React from 'react';
import { Message, Role } from '../types';
import { BotIcon, UserIcon } from './Icons';

interface ChatMessageProps {
  message: Message;
}

const ChatMessage: React.FC<ChatMessageProps> = ({ message }) => {
  const isModel = message.role === Role.MODEL;
  
  const parts = message.text.split('Why this is the best answer:');
  const mainAnswer = parts[0];
  const explanation = parts.length > 1 ? parts[1] : null;

  return (
    <div className={`flex items-start space-x-4 ${isModel ? '' : 'justify-end'}`}>
      {isModel && (
        <div className="flex-shrink-0">
          <BotIcon className="w-8 h-8 text-cyan-400" />
        </div>
      )}

      <div className={`max-w-xl lg:max-w-2xl rounded-lg p-4 ${isModel ? 'bg-gray-800 text-gray-300' : 'bg-cyan-700 text-white'}`}>
        <p className="whitespace-pre-wrap">{mainAnswer.trim()}</p>
        {explanation && (
          <div className="mt-4 pt-3 border-t border-cyan-500/30">
            <h3 className="font-bold text-cyan-300 mb-2">Why this is the best answer:</h3>
            <p className="whitespace-pre-wrap text-gray-400">{explanation.trim()}</p>
          </div>
        )}
      </div>

      {!isModel && (
        <div className="flex-shrink-0">
          <UserIcon className="w-8 h-8 text-gray-500" />
        </div>
      )}
    </div>
  );
};

export default ChatMessage;
