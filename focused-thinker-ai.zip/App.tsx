
import React, { useState, useRef, useEffect, useCallback } from 'react';
import type { Chat } from '@google/genai';
import { Message, Role } from './types';
import { initializeChat } from './services/geminiService';
import ChatMessage from './components/ChatMessage';
import ChatInput from './components/ChatInput';
import { BotIcon, SparklesIcon } from './components/Icons';

const App: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const chatRef = useRef<Chat | null>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatRef.current = initializeChat();
  }, []);

  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSendMessage = useCallback(async (text: string) => {
    if (!chatRef.current) return;
    
    setError(null);
    setIsLoading(true);

    const userMessage: Message = { role: Role.USER, text };
    setMessages(prev => [...prev, userMessage, { role: Role.MODEL, text: '' }]);

    try {
      const stream = await chatRef.current.sendMessageStream({ message: text });
      
      let fullResponse = '';
      for await (const chunk of stream) {
        fullResponse += chunk.text;
        setMessages(prev => {
          const newMessages = [...prev];
          newMessages[newMessages.length - 1].text = fullResponse;
          return newMessages;
        });
      }
    } catch (e) {
      const errorMessage = e instanceof Error ? e.message : 'An unknown error occurred.';
      setError(errorMessage);
      setMessages(prev => [...prev.slice(0, -1), { role: Role.MODEL, text: `Sorry, I ran into an issue: ${errorMessage}` }]);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const WelcomeScreen: React.FC = () => (
    <div className="flex flex-col items-center justify-center h-full text-center text-gray-400 px-4">
      <SparklesIcon className="w-16 h-16 mb-4 text-cyan-400" />
      <h1 className="text-4xl font-bold text-gray-200 mb-2">Focused Thinker AI</h1>
      <p className="max-w-md">
        Get the single best answer, not a list. This helps you learn and remember.
        Ask me anything, or try one of these:
      </p>
      <div className="flex flex-wrap justify-center gap-2 mt-6">
        <button onClick={() => handleSendMessage("What's the best way to learn a new programming language?")} className="bg-gray-800 hover:bg-gray-700 text-sm p-2 rounded-lg transition-colors">"How to learn a new language?"</button>
        <button onClick={() => handleSendMessage("Explain the concept of compound interest simply.")} className="bg-gray-800 hover:bg-gray-700 text-sm p-2 rounded-lg transition-colors">"Explain compound interest."</button>
        <button onClick={() => handleSendMessage("What is a good recipe for a beginner cook?")} className="bg-gray-800 hover:bg-gray-700 text-sm p-2 rounded-lg transition-colors">"A recipe for a beginner."</button>
      </div>
    </div>
  );

  return (
    <div className="flex flex-col h-screen bg-gray-900">
      <header className="flex items-center p-4 border-b border-gray-700/50 shadow-lg">
        <BotIcon className="w-8 h-8 mr-3 text-cyan-400"/>
        <h1 className="text-xl font-bold text-gray-200">Focused Thinker AI</h1>
      </header>
      <main ref={chatContainerRef} className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
        {messages.length === 0 ? (
          <WelcomeScreen />
        ) : (
          messages.map((msg, index) => <ChatMessage key={index} message={msg} />)
        )}
         {isLoading && messages[messages.length-1]?.role === Role.MODEL && (
            <div className="flex items-start space-x-4 animate-pulse">
              <div className="flex-shrink-0">
                <BotIcon className="w-8 h-8 text-cyan-400" />
              </div>
              <div className="bg-gray-800 rounded-lg p-4 w-full">
                <div className="h-4 bg-gray-700 rounded w-1/4"></div>
              </div>
            </div>
          )}
      </main>
      <footer className="p-4 border-t border-gray-700/50 bg-gray-900">
        {error && <p className="text-red-500 text-center text-sm mb-2">{error}</p>}
        <ChatInput onSendMessage={handleSendMessage} isLoading={isLoading} />
      </footer>
    </div>
  );
};

export default App;
